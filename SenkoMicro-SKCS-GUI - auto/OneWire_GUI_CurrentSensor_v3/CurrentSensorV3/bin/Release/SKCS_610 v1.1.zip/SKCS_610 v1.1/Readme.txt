v1.1.0
1. add data log
2. cleafy FAIL and PASS

